# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
  Refile.secret_key = '3919c866d976edc88e8b052e0a57f611c5528ab1fb3d06687459f2d6e92bb727a2cdf1d86b1cdc4e91910a5a80d5c1929ad6a1b1d06b991a5705ba659ab21929'